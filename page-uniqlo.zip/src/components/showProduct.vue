<template>
  <article class="showProductPage">
    <div class="showProduct">
      <div class="showProduct_inner">
        <!--showProduct_inner_cover-->
        <div class="showProduct_inner_cover">
          <div class="showProduct_inner_cover_inf">
            <div class="inf_titleEN">Pantsuits</div>
            <div class="inf_titleTC">女仕服裝</div>
            <div class="inf_content">神采奕奕的生活､由穿搭開始｡</div>
          </div>
          <div class="showProduct_inner_cover_imgBx">
            <img src="../assets/images/product/women/cover.jpg" alt>
          </div>
        </div>
        <!--proList-->
        <proList/>
        <!--showProduct_inner_squares-->
        <div class="showProduct_inner_squares">
          <div class="showProduct_inner_squares_square">
              <div class="square_proImgBx">
                  <img src="../assets/images/product/women/外套/01-1.jpg" alt="">
              </div>
              <div class="square_proContent">
                  <div class="square_proContent_name">BLOCKTECH防風雨 連帽外套</div>
                  <div class="square_proContent_price">NT$2490</div>
                  <div class="square_proContent_other">特價商品等</div>
              </div>
          </div>
          <div class="showProduct_inner_squares_square">
              <div class="square_proImgBx">
                  <img src="../assets/images/product/women/外套/02-1.jpg" alt="">
              </div>
              <div class="square_proContent">
                  <div class="square_proContent_name">AIRism抗UV 網眼連帽外套 (長袖)</div>
                  <div class="square_proContent_price">NT$790</div>
                  <div class="square_proContent_other">特價商品等</div>
              </div>
          </div>
          <div class="showProduct_inner_squares_square">
              <div class="square_proImgBx">
                  <img src="../assets/images/product/women/外套/03-1.jpg" alt="">
              </div>
              <div class="square_proContent">
                  <div class="square_proContent_name">BLOCKTECH防風雨 連帽外套</div>
                  <div class="square_proContent_price">NT$2490</div>
                  <div class="square_proContent_other">特價商品等</div>
              </div>
          </div>
        </div>

      </div>
    </div>
  </article>
</template>

<script>
import proList from "../elements/proList";

export default {
  name: "showProduct",
  props: {
    msg: String
  },
  data() {
    return {
        product:[
            {proID:"",proType:"women",proName:"BLOCKTECH防風雨 連帽外套",proPrice:"2490",proOther:"none"},
            {proID:"",proType:"women",proName:"BLOCKTECH防風雨 連帽外套",proPrice:"2490",proOther:"new"},
            {proID:"",proType:"women",proName:"BLOCKTECH防風雨 連帽外套",proPrice:"2490",proOther:"onSale"}
        ]
    };
  },
  components: {
    proList
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
@import "../assets/styles/reset.css";
@import "../assets/styles/mixin.scss";

.showProduct {
  @include displayFlex();
  width: 100vw;
  margin: 50px 0;
  font-family: $mainFontFamily;
  color: $mainColorBlack;
  .showProduct_inner {
    @include displayFlex(column);
    position: relative;
    max-width: 1000px;
    width: 100%;
    .showProduct_inner_cover {
      @include displayFlex();
      width: 100%;
      border: 1px solid $mainColorWhite;
      .showProduct_inner_cover_inf {
        @include displayFlex(column, center, center);
        width: 50%;
        box-sizing: border-box;
        .inf_titleEN {
          color: $logoRed;
          font-weight: 600;
          margin-bottom: 5px;
        }
        .inf_titleTC {
          font-size: 24px;
          font-weight: 600;
          margin-bottom: 8px;
        }
        .inf_content {
        }
      }
      .showProduct_inner_cover_imgBx {
        @include displayFlex();
        width: 50%;
        height: 465px;
        // background:blue;
        overflow: hidden;
        img {
          width: 100%;
        }
      }
    }

    .showProduct_inner_squares{
        @include displayFlex();
        flex-wrap:wrap;
        width:100%;
        .showProduct_inner_squares_square{
            width:300px;
            margin:0 15px;
            .square_proImgBx{
                width:100%;
                img{
                    width:100%;
                }
            }
            .square_proContent{

            }
        }
    }
  }
}

</style>
