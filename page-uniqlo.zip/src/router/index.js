import Vue from 'vue';
import VueRouter from 'vue-router'; //載入 vue-router

import home from "@/components/home"
import showProduct from "@/components/showProduct"


Vue.use(VueRouter) //使用 vue-router

// =--------------------
/*
const routes = [
  {
    name: 'home',  
    path: '/', 
    component: home
  },
  {
    name: 'showProduct',  
    path: '/showProduct', 
    component: () => import('../components/showProduct.vue'),
  }
];

const router = new VueRouter({
  // mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
*/
//------------------------------------

export default new VueRouter({
  routes: [
    {
      name: 'home',  
      path: '/', 
      component: home
    },
    {
      name: 'showProduct',  
      path: '/showProduct', 
      component: showProduct
    }
  ]
})
